﻿using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using UnityEngine;
using UnityEngine.SceneManagement;
using NANDBrewShipDataParser;
using System.Linq;
using BepInEx.Bootstrap;
//poorly written by pr0skynesis (discord username), parser by NANDBrew
/*
*/
namespace ShipyardCodes
{
    [BepInPlugin(pluginGuid, pluginName, pluginVersion)]
    public class ShipyardCodesMain : BaseUnityPlugin
    {
        // Necessary plugin info
        public const string pluginGuid = "pr0skynesis.shipyardcodes";
        public const string pluginName = "ShipyardCodes";
        public const string pluginVersion = "1.0.0";

        //config file info
        //A) Last saved codes
        public static ConfigEntry<string> code1;
        public static ConfigEntry<string> code2;
        public static ConfigEntry<string> code3;
        public static ConfigEntry<string> code4;
        public static ConfigEntry<string> code5;
        public static ConfigEntry<string> code6;
        public static ConfigEntry<string> code7;
        public static ConfigEntry<string> code8;
        public static ConfigEntry<string> code9;
        public static ConfigEntry<string> code10;
        //B) Main Options

        //variables
        private static AssetBundle bundle;
        private static string assetPath;
        public static GameObject shipyardCodes; //the whole shipyardCodes prefab

        private void Start()    //Load the bundle
        {
            assetPath = Paths.PluginPath + "\\ShipyardCodes\\shipyardCodes";
            bundle = AssetBundle.LoadFromFile(assetPath);
            if (bundle == null)
            {
                Debug.LogError("ShipyardCodes: Bundle not loaded! Did you place it in the correct folder?");
            }
        }
        public void Awake()
        {
            SceneManager.sceneLoaded += SceneLoaded;
            //patching info
            Harmony harmony = new Harmony(pluginGuid);
            MethodInfo original = AccessTools.Method(typeof(ShipyardUI), "ShowUI");
            MethodInfo patch = AccessTools.Method(typeof(ShipyardCodesPatches), "ShowUI_Patch");
            MethodInfo original2 = AccessTools.Method(typeof(ShipyardUI), "HideUI");
            MethodInfo patch2 = AccessTools.Method(typeof(ShipyardCodesPatches), "HideUI_Patch");

            //Create config file in BepInEx\config\
            //A) Last Saved Codes
            code1 = Config.Bind("A) Last Saved Codes", "code1", "", "Previously saved code");
            code2 = Config.Bind("A) Last Saved Codes", "code2", "", "Previously saved code");
            code3 = Config.Bind("A) Last Saved Codes", "code3", "", "Previously saved code");
            code4 = Config.Bind("A) Last Saved Codes", "code4", "", "Previously saved code");
            code5 = Config.Bind("A) Last Saved Codes", "code5", "", "Previously saved code");
            code6 = Config.Bind("A) Last Saved Codes", "code6", "", "Previously saved code");
            code7 = Config.Bind("A) Last Saved Codes", "code7", "", "Previously saved code");
            code8 = Config.Bind("A) Last Saved Codes", "code8", "", "Previously saved code");
            code9 = Config.Bind("A) Last Saved Codes", "code9", "", "Previously saved code");
            code10 = Config.Bind("A) Last Saved Codes", "code10", "", "Previously saved code");
            //B) Main Options

            //apply patches
            harmony.Patch(original, new HarmonyMethod(patch));
            harmony.Patch(original2, new HarmonyMethod(patch2));
        }
        private static void SceneLoaded(Scene scene, LoadSceneMode loadSceneMode)
        {
            if (scene.name == "the ocean")
            {
                SetupThings();
            }
        }
        private static void SetupThings()
        {   //Assigns the bundle content to the correct objects
            if (bundle != null)
            {
                string path = "Assets/ShipyardCodes/shipyardCodes.prefab";
                shipyardCodes = bundle.LoadAsset<GameObject>(path);
                Transform shipyardUI = FindObjectOfType<ShipyardUI>().transform;
                AddButtonComponents();
                shipyardCodes = Instantiate(shipyardCodes, shipyardUI);
                if (!Chainloader.PluginInfos.ContainsKey("com.nandbrew.nandtweaks"))
                {   //check if NANDTweaks is not used
                    shipyardCodes.transform.GetChild(0).localPosition = new Vector3(1.5f, 0f, 0f);
                }
                shipyardCodes.SetActive(false);
            }
            else
            {
                Debug.LogError("ShipyardCodes: Bundle not loaded correctly");
            }
        }
        private static void AddButtonComponents()
        {   //adds the buttons script to the correct buttons
            GameObject openCloseButton = shipyardCodes.transform.GetChild(0).gameObject;
            GameObject saveCodeButton = shipyardCodes.transform.GetChild(1).GetChild(0).gameObject;
            GameObject loadCodeButton = shipyardCodes.transform.GetChild(1).GetChild(1).gameObject;
            GameObject allowAllSailsButton = shipyardCodes.transform.GetChild(1).GetChild(2).gameObject;
            GameObject allowAllPartsButton = shipyardCodes.transform.GetChild(1).GetChild(3).gameObject;

            openCloseButton.AddComponent<OpenCloseButton>();
            saveCodeButton.AddComponent<SaveCodeButton>();
            loadCodeButton.AddComponent<LoadCodeButton>();
            allowAllSailsButton.AddComponent<AllowAllSailsButton>();
            allowAllPartsButton.AddComponent<AllowAllPartsButton>();
            //this should be at the end I think, otherwise you can't add stuff to buttons properly
            shipyardCodes.transform.GetChild(1).gameObject.SetActive(false);
            OpenCloseButton.uiOpen = false;
        }
    }
    public class ShipyardCodesPatches
    {
        private static bool uiOpen;
        [HarmonyPostfix]
        public static void ShowUI_Patch()
        {   //patch to show the modded ui when opening the og ui
            ShipyardCodesMain.shipyardCodes.SetActive(true);
            uiOpen = true;
        }
        [HarmonyPostfix]
        public static void HideUI_Patch()
        {   //patch to hide the modded ui when closing the og ui
            if(uiOpen)
            {   //necessary because the shipyard ui calls HideUI when it awakens and if there isn't this chek
                //it gets messed up
                ShipyardCodesMain.shipyardCodes.SetActive(false);
                uiOpen = false;
            }
        }
    }
    public class ManageCodes
    {   //to manage (save, load, apply) the codes
        public static bool allowAllSails = true;
        public static bool allowAllParts = true;
        public static void SaveCode()
        {
            GameObject boat = GameState.currentShipyard.GetCurrentBoat();
            SaveBoatCustomizationData data = boat.GetComponent<SaveableBoatCustomization>().GetData();
            string code = ShareableConfigUtility.CreateShipConfig(data, boat, true);
            SaveToConfig(code);
            CopyToClipboard(code);
            Debug.LogWarning("ShipyardCodes: " + code);
        }
        public static void LoadCode()
        {   //loads the code on the boat
            //string testCode = "@JM323xw(175n80f98i1Q9f00Bac21QapO1Oaf01ec9I0EeeI0EgeI";  //OG topmast schooner
            //string testCode = "@JM323xw(175n80f9c-1Q9ds0Baeo1OafO1Qarm1eccQ0EeeI0EgeI";     //OG rearranged
            //string testCode = "@J2h05whw(0Ybl60ac9o16zqA";    //lateens
            //                   @J2h05M01g(0Ybl60ac9o16zqA     //lateens with cabins
            //string testCode = "@J2Mwhw(0f9dM1bahQ0fcdM";    //three mast schooner gaffs and modded bowsprit
            //string testCode = "@J2xMx01(0fbdM0fddM";        //two mast schooner, modded topmast, bowsprit and telltale
            //string testCode = "@C041g10x0(0x69o0J8660Kw3Q0IA9o"; //modded cog
            //string testCode = "@C041g102h0(0x69o0J8660IA9o";  // modded cog 2 
            //                   Cxg(0x58s0J866                 //unmodded cog 1
            //                   CM0(0y4hw0B6fa                 //unmodded cog 2

            string code = PasteFromClipboard();
            //0a) Chech if there if the what comes from the clipboard is a code
            if (!code.StartsWith("@D") && !code.StartsWith("@S") && !code.StartsWith("@C") && !code.StartsWith("@B") && !code.StartsWith("@J") && !code.StartsWith("@K") && !code.StartsWith("D") && !code.StartsWith("S") && !code.StartsWith("C") && !code.StartsWith("B") && !code.StartsWith("J") && !code.StartsWith("K"))
            {
                NotificationUi.instance.ShowNotification("No code found in the clipboard");
                return;
            }
            Shipyard shipyard = GameState.currentShipyard;
            GameObject boat = shipyard.GetCurrentBoat();
            BoatRefs refs = boat.GetComponent<BoatRefs>();
            BoatCustomParts parts = boat.GetComponent<BoatCustomParts>();
            SaveBoatCustomizationData data = ShareableConfigUtility.ParseShipConfig(code, boat, true);
            Mast[] masts = refs.masts;
            //0b) Check code for boat
            code = code.TrimStart('@');
            if (ShareableConfigUtility.boatIndexes[code.First().ToString()] != boat.GetComponent<SaveableObject>().sceneIndex)
            {   //check if code is not for this boat
                NotificationUi.instance.ShowNotification("Code is for another boat!");
                return;
            }
            //1) Remove all existing sails (adding refunds)
            foreach (Mast mast in masts)
            {   
                if (!mast || !mast.gameObject.activeInHierarchy)
                {
                    continue;
                }
                foreach (GameObject sail in mast.sails)
                {   //adds refunds for all removed sails
                    Sail sailComponent = sail.GetComponent<Sail>();
                    shipyard.AddRefund(new ShipyardRefund(sailComponent.sailName, Mathf.RoundToInt(sailComponent.GetSailPrice() * shipyard.GetCurrencyRate() * 0.5f)));
                }
                mast.RemoveAllSails();
            }
            //2) Update active masts and active parts, update order
            for (int i = 0; i < parts.availableParts.Count; i++)
            {
                if (allowAllParts || parts.availableParts[i].category != 1)
                {   //load a part only if allowAllParts = true or part is not in the optional category.
                    int change = data.partActiveOptions[i] - parts.availableParts[i].activeOption;
                    shipyard.partsInstaller.ChangeOrderedOption(i, change);
                }
            }
            //3) Add sails in the right spot, update the order
            for (int i = 0; i < masts.Length; i++)
            {
                for (int j = 0; j < data.sails.Count; j++)
                {
                    if (data.sails[j].mastIndex == i)
                    {   //if the j-esime sail belongs to the i-esime mast we do the following
                        GameObject sailObject;
                        if (allowAllSails)
                        {   //cheaty load options that loads sails not normally available here
                            sailObject = PrefabsDirectory.instance.sails[data.sails[j].prefabIndex];
                        }
                        else
                        {   //only load a sail if it's available in the current shipyard
                            sailObject = shipyard.sailPrefabs.FirstOrDefault(go => go.GetComponent<Sail>()?.prefabIndex == data.sails[j].prefabIndex);
                        }
                        if (sailObject != null)
                        {
                            shipyard.sailInstaller.SelectMast(masts[i]);
                            shipyard.AddNewSail(sailObject);
                            Sail addedSail = masts[i].GetComponentsInChildren<Sail>().Last();
                            float heightChange = data.sails[j].installHeight - addedSail.GetCurrentInstallHeight();
                            addedSail.ChangeInstallHeight(heightChange);
                            shipyard.sailInstaller.MoveHeldSail(0f);
                        }
                        else
                        {
                            //Debug.LogWarning("ShipyardCodes: sail not available in this port");
                        }
                    }
                }
            }
        }
        public static void CopyToClipboard(string text)
        {
            GUIUtility.systemCopyBuffer = text;
        }
        public static string PasteFromClipboard()
        {
            return GUIUtility.systemCopyBuffer;
        }
        public static void SaveToConfig(string code)
        {   //saves the last saved code to the configuration file
            for (int i = 0; i < 10; i++)
            {
                int j = 9 - i;
                if (j != 0)
                {   //eg. i = 8 , i + 1 = 9 OK assigne code9 to code10
                    SetConfigCode(j, GetConfigCode(j - 1));
                }
                else
                {   //assign the last saved code to code1
                    SetConfigCode(j, code);
                }
            }
        }
        private static void SetConfigCode(int i, string code)
        {   //sets the current value of a code saved to config
            switch (i)
            {
                case 0: ShipyardCodesMain.code1.Value = code; break;
                case 1: ShipyardCodesMain.code2.Value = code; break;
                case 2: ShipyardCodesMain.code3.Value = code; break;
                case 3: ShipyardCodesMain.code4.Value = code; break;
                case 4: ShipyardCodesMain.code5.Value = code; break;
                case 5: ShipyardCodesMain.code6.Value = code; break;
                case 6: ShipyardCodesMain.code7.Value = code; break;
                case 7:  ShipyardCodesMain.code8.Value = code; break;
                case 8: ShipyardCodesMain.code9.Value = code; break;
                case 9: ShipyardCodesMain.code10.Value = code; break;
            }
        }
        private static string GetConfigCode(int i)
        {   //gets the current value of a code saved to the config
            switch (i)
            {
                case 0: return ShipyardCodesMain.code1.Value;
                case 1: return ShipyardCodesMain.code2.Value;
                case 2: return ShipyardCodesMain.code3.Value;
                case 3: return ShipyardCodesMain.code4.Value;
                case 4: return ShipyardCodesMain.code5.Value;
                case 5: return ShipyardCodesMain.code6.Value;
                case 6: return ShipyardCodesMain.code7.Value;
                case 7: return ShipyardCodesMain.code8.Value;
                case 8: return ShipyardCodesMain.code9.Value;
                case 9: return ShipyardCodesMain.code10.Value;
                default : return null;
            }
        }

    }
    //BUTTONS SCRIPTS (need to be attached to the correct button)
    public class OpenCloseButton : GoPointerButton
    {   //open / close button script to show and hide the ui element we added to the og shipyard ui 
        public static bool uiOpen;
        public override void OnActivate()
        {
            if (uiOpen)
            {
                uiOpen = !uiOpen;
                ShipyardCodesMain.shipyardCodes.transform.GetChild(1).gameObject.SetActive(false);
            }
            else
            {
                uiOpen = !uiOpen;
                ShipyardCodesMain.shipyardCodes.transform.GetChild(1).gameObject.SetActive(true);
            }
        }
    }
    public class SaveCodeButton : GoPointerButton
    {   //save code button script
        public override void OnActivate()
        {
            ManageCodes.SaveCode();
        }
    }
    public class LoadCodeButton : GoPointerButton
    {   //load code button script
        public override void OnActivate()
        {
            ManageCodes.LoadCode();
        }
    }
    public class AllowAllSailsButton : GoPointerButton
    {   //controls the button that toggles loading all sails or only the one available in the current shipyard
        public static TextMesh allowAllSailsStatusText;
        public override void OnActivate()
        {
            if (ManageCodes.allowAllSails)
            {
                ManageCodes.allowAllSails = false;
                //allowAllSailsStatusText.text = "No";
                transform.parent.GetChild(4).GetChild(0).gameObject.GetComponent<TextMesh>().text = "No";
            }
            else
            {
                ManageCodes.allowAllSails = true;
                //allowAllSailsStatusText.text = "Yes";
                transform.parent.GetChild(4).GetChild(0).gameObject.GetComponent<TextMesh>().text = "Yes";
            }
        }
    }
    public class AllowAllPartsButton : GoPointerButton
    {   //controls the button that toggles loading all parts or only the sailplan
        public TextMesh allowAllPartsStatusText;
        public override void OnActivate()
        {
            if (ManageCodes.allowAllParts)
            {
                ManageCodes.allowAllParts = false;
                //allowAllPartsStatusText.text = "No";
                transform.parent.GetChild(4).GetChild(1).gameObject.GetComponent<TextMesh>().text = "No";
            }
            else
            {
                ManageCodes.allowAllParts = true;
                //allowAllPartsStatusText.text = "Yes";
                transform.parent.GetChild(4).GetChild(1).gameObject.GetComponent<TextMesh>().text = "Yes";
            }
        }
    }
}
